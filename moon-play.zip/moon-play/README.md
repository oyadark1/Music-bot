# Moon Play 🌙

Music app (Android, Jetpack Compose) + Node.js backend.

## Features
- Moon-themed UI: splash, home, dark playlist page, vinyl Now Playing
- Search + playback (Media3, background and lock-screen controls)
- Synced lyrics (LRC) on the Now Playing screen, with Original / Translation versions
- **Lyrics Island**: floating pill at the top of the screen (Android's take on Dynamic Island) that shows the current lyric line over any app
- Downloads for offline listening (where the provider allows it)
- Playlists, share by link/code (`moonplay://playlist/<code>`), share with friends as collaborators
- Friends (search, request, accept) and realtime chat (Socket.IO)

## Run the server
```bash
cd server
cp .env.example .env
npm install
npm start        # http://localhost:4000
```
Without API keys it serves a small demo catalog (no audio) with placeholder lyrics.

**For real, full-length songs** add a free Jamendo key to `server/.env`
(`JAMENDO_CLIENT_ID`, from https://devportal.jamendo.com). Jamendo is Creative Commons music, so it
streams in full and many tracks can be downloaded for offline play. Synced lyrics come from
[LRCLIB](https://lrclib.net) with no key; many songs have several lyric versions and the Now Playing
screen has a chip to flip between them (the floating lyrics island follows the same version).

## Run the app
Open `android/` in Android Studio, run on an emulator (it talks to `http://10.0.2.2:4000`).
Change `API_BASE` in `android/app/build.gradle.kts` for a deployed server.

## Music and lyrics licensing
Full songs and lyrics need licensed providers. `server/src/music.js` has hooks for
Jamendo (full songs, default), Spotify (metadata/30 s previews) and Musixmatch (synced lyrics and
translations, commercial licence). Catalog priority: Jamendo, then Spotify, then the demo catalog.
Lyrics: Musixmatch if keyed, otherwise LRCLIB. Mainstream chart music needs a licensed streaming
source; this repo does not bundle copyrighted songs or lyrics.

## Status
Not yet compiled or run end to end (the server and the Android app were both written without being built).
Done since the first scaffold: stays signed in, Jamendo catalog, LRCLIB lyric versions, playlist tracks keep
their stream/download URLs (adding a song to a playlist used to fail), delete playlist, playlist cards in chat
that friends tap to add, links open while the app is running, Android 14 foreground-service fix for the lyrics island.
TODO: compile and fix any Android build errors, automated tests, push notifications for chat, swap the JSON file
store for Postgres before real users.

On Android 14+ the island needs the "Display over other apps" permission (the Library switch sends you there).
