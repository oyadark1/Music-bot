# Moon Play 🌙

An offline music player for Android (Jetpack Compose). No server, no account.

## Features
- Plays the music stored on your phone (asks permission to read audio; nothing is uploaded)
- Moon-themed UI: splash, home, dark playlist page, vinyl Now Playing
- Background playback with lock-screen / notification controls (Media3)
- Synced lyrics on Now Playing. Lyrics are looked up once on [LRCLIB](https://lrclib.net) and saved on the phone, so they keep working offline. When a song has several lyric versions, tap the chip to flip between them
- **Lyrics Island**: floating pill at the top of the screen (Android's take on Dynamic Island) showing the current lyric line over any app
- Playlists you make yourself, saved on the phone
- Share a playlist as a link or code (it carries song names; the other phone needs the same songs). Paste a code in Library to add one

## Not included (they need a server)
Accounts / Google sign-in, friends, chat, and downloading music.

## Build
Open `android/` in Android Studio and run, or push to GitHub: the workflow in `.github/workflows` builds a debug APK (Actions tab -> run -> Artifacts).
On Android 14+ the island needs "Display over other apps" (the Library switch takes you there).

## Status
Not yet confirmed to compile on a clean build; fix any errors the CI log shows.
