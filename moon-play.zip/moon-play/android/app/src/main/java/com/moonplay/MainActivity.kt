package com.moonplay

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.moonplay.player.PlaybackService
import com.moonplay.ui.App
import com.moonplay.ui.MoonApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        App.init(this)

        // Start the player service so Playback.player is ready
        startService(Intent(this, PlaybackService::class.java))
        MediaController.Builder(this, SessionToken(this, ComponentName(this, PlaybackService::class.java))).buildAsync()

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        handleLink(intent)
        setContent { MoonApp(pendingShareCode = null) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleLink(intent)
    }

    // moonplay://playlist/<code> from a shared link (works on cold start and while running)
    private fun handleLink(i: Intent?) {
        i?.data?.takeIf { it.scheme == "moonplay" }?.lastPathSegment?.let { App.pendingShare = it }
    }
}
