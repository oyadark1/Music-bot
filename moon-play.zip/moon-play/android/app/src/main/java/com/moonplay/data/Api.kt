package com.moonplay.data

import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import com.moonplay.BuildConfig
import kotlinx.serialization.json.Json
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.http.*

interface MoonApi {
    @POST("auth/register") suspend fun register(@Body c: Credentials): AuthResponse
    @POST("auth/login") suspend fun login(@Body c: Credentials): AuthResponse

    @GET("music/search") suspend fun search(@Query("q") q: String): List<Track>
    @GET("music/lyrics") suspend fun lyrics(
        @Query("title") title: String,
        @Query("artist") artist: String,
        @Query("variant") variant: String = "original",
        @Query("lang") lang: String = "en",
        @Query("index") index: Int = 0,
        @Query("durationMs") durationMs: Long = 0,
    ): Lyrics

    @GET("playlists") suspend fun playlists(): List<Playlist>
    @POST("playlists") suspend fun createPlaylist(@Body p: NewPlaylist): Playlist
    @GET("playlists/{id}") suspend fun playlist(@Path("id") id: String): Playlist
    @DELETE("playlists/{id}") suspend fun deletePlaylist(@Path("id") id: String)
    @POST("playlists/{id}/tracks") suspend fun addTrack(@Path("id") id: String, @Body t: Track): Playlist
    @GET("playlists/shared/{code}") suspend fun sharedPlaylist(@Path("code") code: String): Playlist
    @POST("playlists/shared/{code}/save") suspend fun saveShared(@Path("code") code: String): Playlist
    @POST("playlists/{id}/share/{friendId}") suspend fun shareWithFriend(@Path("id") id: String, @Path("friendId") friendId: String): Playlist

    @GET("friends") suspend fun friends(): Friends
    @GET("friends/search") suspend fun searchUsers(@Query("q") q: String): List<User>
    @POST("friends/request/{userId}") suspend fun requestFriend(@Path("userId") id: String)
    @POST("friends/accept/{requestId}") suspend fun acceptFriend(@Path("requestId") id: String)

    @GET("chat/{friendId}") suspend fun chatHistory(@Path("friendId") id: String): List<ChatMessage>
}

object Api {
    @Volatile var token: String? = null

    private val json = Json { ignoreUnknownKeys = true; coerceInputValues = true }

    val client: OkHttpClient = OkHttpClient.Builder()
        .addInterceptor(Interceptor { chain ->
            val b = chain.request().newBuilder()
            token?.let { b.header("Authorization", "Bearer $it") }
            chain.proceed(b.build())
        })
        .build()

    val service: MoonApi = Retrofit.Builder()
        .baseUrl(BuildConfig.API_BASE + "/")
        .client(client)
        .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
        .build()
        .create(MoonApi::class.java)
}
