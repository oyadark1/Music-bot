package com.moonplay.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.File

/**
 * Offline downloads. Only tracks whose licensed provider returns a downloadable
 * [Track.streamUrl] can be saved; files live in app-private storage.
 */
class Downloads(private val context: Context) {
    private val dir get() = File(context.filesDir, "downloads").apply { mkdirs() }

    fun fileFor(track: Track) = File(dir, track.key.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".mp3")
    fun isDownloaded(track: Track) = fileFor(track).exists()
    fun localUri(track: Track): String? = fileFor(track).takeIf { it.exists() }?.toURI()?.toString()

    suspend fun download(track: Track, onProgress: (Float) -> Unit = {}): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val source = track.downloadUrl.ifEmpty { track.streamUrl }
            require(source.isNotEmpty()) { "This track is not available for download" }
            val out = fileFor(track)
            val tmp = File(out.path + ".part")
            Api.client.newCall(Request.Builder().url(source).build()).execute().use { resp ->
                check(resp.isSuccessful) { "Download failed (${resp.code})" }
                val body = resp.body ?: error("Empty response")
                val total = body.contentLength().coerceAtLeast(1)
                var read = 0L
                body.byteStream().use { input ->
                    tmp.outputStream().use { output ->
                        val buf = ByteArray(16 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            output.write(buf, 0, n)
                            read += n
                            onProgress(read.toFloat() / total)
                        }
                    }
                }
            }
            tmp.renameTo(out)
            out
        }
    }

    fun delete(track: Track) = fileFor(track).delete()
    fun all(): List<File> = dir.listFiles()?.toList().orEmpty()
}
