package com.moonplay.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Reads the music already on the phone. Works fully offline. */
object Library {
    suspend fun scan(ctx: Context): List<Track> = withContext(Dispatchers.IO) {
        val out = mutableListOf<Track>()
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val art = Uri.parse("content://media/external/audio/albumart")
        val cols = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION,
        )
        val where = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 10000"
        runCatching {
            ctx.contentResolver.query(base, cols, where, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    val artist = c.getString(iArtist).orEmpty().let { if (it.isBlank() || it == "<unknown>") "Unknown artist" else it }
                    out += Track(
                        id = id.toString(),
                        title = c.getString(iTitle).orEmpty().ifBlank { "Untitled" },
                        artist = artist,
                        album = c.getString(iAlbum).orEmpty(),
                        durationMs = c.getLong(iDur),
                        uri = ContentUris.withAppendedId(base, id).toString(),
                        artwork = ContentUris.withAppendedId(art, c.getLong(iAlbumId)).toString(),
                    )
                }
            }
        }
        out
    }
}
