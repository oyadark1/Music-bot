package com.moonplay.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

@Serializable
internal data class LyricVersion(val label: String = "", val synced: String = "", val plain: String = "")

@Serializable
internal data class LrclibItem(
    val trackName: String? = null, val artistName: String? = null, val duration: Double? = null,
    val syncedLyrics: String? = null, val plainLyrics: String? = null,
)

/**
 * Lyrics from LRCLIB (open, no key). The first lookup needs internet; every version found is then
 * saved on the phone, so those lyrics keep working offline (including on the floating island).
 */
object LyricsRepo {
    private lateinit var dir: File
    private val client = OkHttpClient.Builder().callTimeout(15, TimeUnit.SECONDS).build()
    private val ser = ListSerializer(LyricVersion.serializer())
    private val itemsSer = ListSerializer(LrclibItem.serializer())

    fun init(ctx: Context) { dir = File(ctx.filesDir, "lyrics").apply { mkdirs() } }

    suspend fun get(t: Track, index: Int = 0): Lyrics = withContext(Dispatchers.IO) {
        val versions = cached(t) ?: fetch(t)?.also { save(t, it) } ?: emptyList()
        if (versions.isEmpty()) return@withContext Lyrics(source = "none")
        val i = index.coerceIn(0, versions.lastIndex)
        val v = versions[i]
        Lyrics("lrclib", parse(v.synced), v.plain, i, versions.size, v.label)
    }

    private fun file(t: Track) = File(dir, t.key.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".json")

    private fun cached(t: Track): List<LyricVersion>? =
        runCatching { file(t).takeIf { it.exists() }?.readText()?.let { Store.json.decodeFromString(ser, it) } }.getOrNull()

    private fun save(t: Track, v: List<LyricVersion>) {
        runCatching { file(t).writeText(Store.json.encodeToString(ser, v)) }
    }

    /** null = couldn't reach LRCLIB (don't cache); empty list = reached it, nothing found. */
    private fun fetch(t: Track): List<LyricVersion>? = runCatching {
        val url = "https://lrclib.net/api/search".toHttpUrl().newBuilder().addQueryParameter("track_name", t.title)
            .apply { if (t.artist != "Unknown artist") addQueryParameter("artist_name", t.artist) }.build()
        client.newCall(Request.Builder().url(url).header("User-Agent", "MoonPlay/0.2").build()).execute().use { r ->
            if (!r.isSuccessful) return@use null
            val want = t.durationMs / 1000.0
            Store.json.decodeFromString(itemsSer, r.body?.string().orEmpty())
                .filter { !it.syncedLyrics.isNullOrBlank() || !it.plainLyrics.isNullOrBlank() }
                .sortedWith(
                    compareBy<LrclibItem> { it.syncedLyrics.isNullOrBlank() }
                        .thenBy { Math.abs((it.duration ?: 0.0) - want) },
                )
                .map {
                    LyricVersion(
                        label = listOfNotNull(it.trackName, it.artistName).joinToString(" · "),
                        synced = it.syncedLyrics.orEmpty(), plain = it.plainLyrics.orEmpty(),
                    )
                }
        }
    }.getOrNull()

    /** "[mm:ss.xx] line" -> timed lines. Unsynced text gives an empty list (plain text is used instead). */
    fun parse(lrc: String): List<LyricLine> {
        val out = mutableListOf<LyricLine>()
        val re = Regex("""^\[(\d+):(\d+(?:\.\d+)?)](.*)$""")
        for (line in lrc.lines()) {
            val m = re.find(line.trim()) ?: continue
            val (min, sec, text) = m.destructured
            out += LyricLine(((min.toLong() * 60 + sec.toDouble()) * 1000).toLong(), text.trim())
        }
        return out.sortedBy { it.timeMs }
    }
}
