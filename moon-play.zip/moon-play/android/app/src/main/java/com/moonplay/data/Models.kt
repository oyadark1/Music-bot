package com.moonplay.data

import kotlinx.serialization.Serializable

@Serializable data class User(val id: String, val username: String, val name: String = "")
@Serializable data class AuthResponse(val token: String, val user: User)
@Serializable data class Credentials(val username: String, val password: String, val name: String? = null)

@Serializable
data class Track(
    val id: String = "",
    val trackId: String = "",
    val title: String,
    val artist: String,
    val album: String = "",
    val durationMs: Long = 0,
    val artwork: String = "",
    val streamUrl: String = "",
    val downloadUrl: String = "", // only set when the artist's licence allows downloads
) {
    val key get() = id.ifEmpty { trackId }
}

@Serializable
data class Playlist(
    val id: String,
    val shareCode: String,
    val ownerId: String,
    val name: String,
    val description: String = "",
    val isPublic: Boolean = false,
    val collaborators: List<String> = emptyList(),
    val tracks: List<Track> = emptyList(),
)
@Serializable data class NewPlaylist(val name: String, val description: String = "")

@Serializable data class LyricLine(val timeMs: Long, val text: String)
@Serializable
data class Lyrics(
    val source: String = "",
    val synced: List<LyricLine> = emptyList(),
    val plain: String = "",
    val index: Int = 0,   // which lyric version this is
    val count: Int = 1,   // how many versions exist (flip with Api.lyrics(index = ...))
    val label: String = "",
)

@Serializable data class FriendRequest(val id: String, val user: User)
@Serializable data class Friends(
    val friends: List<User> = emptyList(),
    val incoming: List<FriendRequest> = emptyList(),
    val outgoing: List<FriendRequest> = emptyList(),
)

@Serializable
data class ChatMessage(
    val id: String,
    val from: String,
    val to: String,
    val text: String = "",
    val at: Long = 0,
    val attachment: Attachment? = null,
)

/** A playlist shared inside a chat message. */
@Serializable data class Attachment(val type: String = "playlist", val shareCode: String = "", val name: String = "")
