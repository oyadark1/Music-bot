package com.moonplay.data

import kotlinx.serialization.Serializable

/** A song stored on this phone. [uri] is its MediaStore content URI. */
@Serializable
data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String = "",
    val durationMs: Long = 0,
    val uri: String,
    val artwork: String = "",
) {
    val key get() = id
}

@Serializable
data class Playlist(val id: String, val name: String, val tracks: List<Track> = emptyList())

@Serializable data class LyricLine(val timeMs: Long, val text: String)

@Serializable
data class Lyrics(
    val source: String = "",
    val synced: List<LyricLine> = emptyList(),
    val plain: String = "",
    val index: Int = 0,   // which lyric version this is
    val count: Int = 1,   // how many versions exist
    val label: String = "",
)

/** What a shared playlist link carries: just song names, so it works for any phone that has those songs. */
@Serializable data class SharedItem(val t: String, val a: String)
@Serializable data class SharedPlaylist(val n: String, val i: List<SharedItem>)
