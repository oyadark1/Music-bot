package com.moonplay.data

import android.content.Context
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json
import java.io.File

/** Playlists and recently played, saved as small files on the phone. */
object Store {
    private lateinit var dir: File
    val json = Json { ignoreUnknownKeys = true; coerceInputValues = true }
    private val playlistsSer = ListSerializer(Playlist.serializer())
    private val idsSer = ListSerializer(String.serializer())

    fun init(ctx: Context) { dir = ctx.filesDir }

    fun loadPlaylists(): List<Playlist> = read("playlists.json") { json.decodeFromString(playlistsSer, it) } ?: emptyList()
    fun savePlaylists(list: List<Playlist>) = write("playlists.json", json.encodeToString(playlistsSer, list))

    fun loadRecentIds(): List<String> = read("recent.json") { json.decodeFromString(idsSer, it) } ?: emptyList()
    fun saveRecentIds(ids: List<String>) = write("recent.json", json.encodeToString(idsSer, ids))

    private fun <T> read(name: String, parse: (String) -> T): T? =
        runCatching { File(dir, name).takeIf { it.exists() }?.readText()?.let(parse) }.getOrNull()

    private fun write(name: String, text: String) {
        runCatching {
            val tmp = File(dir, "$name.tmp")
            tmp.writeText(text)
            tmp.renameTo(File(dir, name))
        }
    }
}
