package com.moonplay.island

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.moonplay.data.Api
import com.moonplay.data.LyricLine
import com.moonplay.data.Track
import com.moonplay.player.Playback
import kotlinx.coroutines.*

/** Shared lyrics state: the app picks the variant (original / translation / romanised...). */
object LyricsStore {
    @Volatile var variant: String = "original"
    @Volatile var lang: String = "en"
    @Volatile var index: Int = 0 // which lyric version (0 = best match)
}

/**
 * "Dynamic Island" for Android: a floating pill at the top of the screen that shows the
 * current synced lyric line while music plays, even over other apps.
 * Tap = play/pause, long-press = hide until next track.
 * Requires the "Display over other apps" permission (see [hasPermission]).
 */
class LyricsIslandService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var wm: WindowManager
    private var pill: LinearLayout? = null
    private lateinit var current: TextView
    private lateinit var next: TextView

    private var lines: List<LyricLine> = emptyList()
    private var loadedFor: String? = null
    private var loadedVariant: String? = null
    private var loadedIndex: Int = -1
    private var hiddenForTrack: String? = null

    private val tick = object : Runnable {
        override fun run() {
            update()
            main.postDelayed(this, 150)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 34) {
            // Android 14+: the type must match the manifest (specialUse), or startForeground throws
            startForeground(NOTIF_ID, buildNotification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(NOTIF_ID, buildNotification())
        if (hasPermission(this)) addPill() else stopSelf()
        main.post(tick)
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Lyrics island", NotificationManager.IMPORTANCE_MIN))
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("Moon Play lyrics island")
            .setContentText("Showing live lyrics")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
    }

    private fun addPill() {
        fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

        current = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; maxLines = 1
        }
        next = TextView(this).apply {
            setTextColor(Color.parseColor("#B8A9E8")); textSize = 12f
            gravity = Gravity.CENTER; maxLines = 1
        }
        pill = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(Color.parseColor("#E61B1033")) // deep moon purple, slightly translucent
            }
            addView(current); addView(next)
            visibility = View.GONE
            setOnClickListener { Playback.toggle() }
            setOnLongClickListener { hiddenForTrack = Playback.currentTrack()?.key; visibility = View.GONE; true }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(12)
            width = (resources.displayMetrics.widthPixels * 0.86f).toInt()
        }
        wm.addView(pill, lp)
    }

    private fun update() {
        val view = pill ?: return
        val player = Playback.player
        val track = Playback.currentTrack()
        if (player == null || track == null || !player.isPlaying || hiddenForTrack == track.key) {
            if (player?.isPlaying != true || track == null) view.visibility = View.GONE
            return
        }
        if (loadedFor != track.key || loadedVariant != LyricsStore.variant || loadedIndex != LyricsStore.index) loadLyrics(track)

        val pos = player.currentPosition
        val idx = lines.indexOfLast { it.timeMs <= pos }
        val text = lines.getOrNull(idx)?.text?.ifBlank { "♪" } ?: "${track.title} • ${track.artist}"
        if (current.text != text) current.text = text
        next.text = lines.getOrNull(idx + 1)?.text.orEmpty()
        view.visibility = View.VISIBLE
    }

    private fun loadLyrics(track: Track) {
        loadedFor = track.key
        loadedVariant = LyricsStore.variant
        loadedIndex = LyricsStore.index
        lines = emptyList()
        scope.launch {
            lines = runCatching {
                withContext(Dispatchers.IO) {
                    Api.service.lyrics(track.title, track.artist, LyricsStore.variant, LyricsStore.lang, LyricsStore.index, track.durationMs).synced
                }
            }.getOrDefault(emptyList())
        }
    }

    override fun onDestroy() {
        main.removeCallbacks(tick)
        scope.cancel()
        pill?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "island"
        private const val NOTIF_ID = 42

        fun hasPermission(c: Context) = Settings.canDrawOverlays(c)

        fun requestPermission(c: Context) = c.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:${c.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )

        fun start(c: Context) = c.startForegroundService(Intent(c, LyricsIslandService::class.java))
        fun stop(c: Context) { c.stopService(Intent(c, LyricsIslandService::class.java)) }
    }
}
