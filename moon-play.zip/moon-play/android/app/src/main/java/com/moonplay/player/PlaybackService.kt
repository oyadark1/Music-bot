package com.moonplay.player

import android.content.Intent
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.moonplay.data.Track

/** Background playback + notification / lock-screen controls (Media3). */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this).build()
        session = MediaSession.Builder(this, player).build()
        Playback.attach(player)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }
}

/** Process-wide handle the UI and lyrics pill use to control and observe the player. */
object Playback {
    var player: ExoPlayer? = null
        private set
    var queue: List<Track> = emptyList()
        private set

    fun attach(p: ExoPlayer) { player = p }

    fun toMediaItem(t: Track): MediaItem =
        MediaItem.Builder()
            .setMediaId(t.key)
            .setUri(t.uri)
            .setMediaMetadata(
                MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist).setAlbumTitle(t.album)
                    .setArtworkUri(t.artwork.takeIf { it.isNotEmpty() }?.let { android.net.Uri.parse(it) }).build()
            )
            .build()

    fun playQueue(tracks: List<Track>, startIndex: Int) {
        val p = player ?: return
        queue = tracks
        p.setMediaItems(tracks.map { toMediaItem(it) }, startIndex, 0)
        p.prepare()
        p.play()
    }

    fun currentTrack(): Track? = player?.currentMediaItemIndex?.let { queue.getOrNull(it) }

    fun toggle() { player?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { player?.seekToNextMediaItem() }
    fun previous() { player?.seekToPreviousMediaItem() }
    fun shuffle(on: Boolean) { player?.shuffleModeEnabled = on }
    fun repeat(on: Boolean) { player?.repeatMode = if (on) Player.REPEAT_MODE_ALL else Player.REPEAT_MODE_OFF }
}
