package com.moonplay.ui

import android.content.Context
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import com.moonplay.data.*
import com.moonplay.island.LyricsStore
import com.moonplay.player.Playback
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

/** Single source of truth for the UI. Everything lives on the phone; no server. */
object App {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var appContext: Context
    private var initialized = false

    var message by mutableStateOf<String?>(null) // shown as a small popup
    var hasPermission by mutableStateOf(false)
    var scanning by mutableStateOf(false)
    var songs by mutableStateOf<List<Track>>(emptyList())
    var playlists by mutableStateOf<List<Playlist>>(emptyList())
    var recent = mutableStateListOf<Track>()
    var pendingShare by mutableStateOf<String?>(null) // from a moonplay://playlist/<code> link

    // player mirror
    var nowPlaying by mutableStateOf<Track?>(null)
    var isPlaying by mutableStateOf(false)
    var positionMs by mutableStateOf(0L)
    var lyrics by mutableStateOf<Lyrics?>(null)

    fun init(context: Context) {
        if (initialized) return
        initialized = true
        appContext = context.applicationContext
        Store.init(appContext)
        LyricsRepo.init(appContext)
        playlists = Store.loadPlaylists()
    }

    // ---- music on the phone ----
    fun refreshLibrary() {
        if (scanning) return
        scanning = true
        scope.launch {
            songs = Library.scan(appContext)
            val byId = songs.associateBy { it.id }
            recent.clear()
            recent.addAll(Store.loadRecentIds().mapNotNull { byId[it] })
            scanning = false
        }
    }

    // ---- player ----
    private var bound = false

    fun bindPlayer() {
        if (bound) return
        scope.launch {
            var tries = 0
            while (Playback.player == null && tries++ < 50) delay(200) // service starts asynchronously
            val p = Playback.player ?: return@launch
            if (bound) return@launch
            bound = true
            isPlaying = p.isPlaying
            p.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
                override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                    nowPlaying = Playback.currentTrack()
                    nowPlaying?.let { t ->
                        recent.removeAll { it.key == t.key }; recent.add(0, t)
                        while (recent.size > 30) recent.removeAt(recent.lastIndex)
                        Store.saveRecentIds(recent.map { it.id })
                        loadLyrics(t)
                    }
                }
            })
        }
    }

    fun play(list: List<Track>, index: Int) {
        val track = list.getOrNull(index) ?: return
        scope.launch {
            var tries = 0
            while (Playback.player == null && tries++ < 25) delay(200) // first tap can beat the service
            Playback.playQueue(list, index)
        }
        nowPlaying = track
        loadLyrics(track)
    }

    // ---- lyrics ----
    fun loadLyrics(t: Track, index: Int = 0) {
        lyrics = null
        LyricsStore.index = index // the floating island follows the same version
        scope.launch { lyrics = LyricsRepo.get(t, index) }
    }

    /** "Different lyrics": flip to the next version found for this song. */
    fun nextLyricsVersion() {
        val t = nowPlaying ?: return
        val l = lyrics ?: return
        if (l.count > 1) loadLyrics(t, (l.index + 1) % l.count)
    }

    // ---- playlists ----
    private fun savePlaylists(list: List<Playlist>) { playlists = list; Store.savePlaylists(list) }

    fun createPlaylist(name: String, first: Track? = null) {
        savePlaylists(playlists + Playlist(UUID.randomUUID().toString(), name, listOfNotNull(first)))
        message = if (first != null) "Added to “$name”" else "Playlist “$name” created"
    }

    fun addToPlaylist(p: Playlist, t: Track) {
        if (p.tracks.any { it.id == t.id }) { message = "Already in “${p.name}”"; return }
        savePlaylists(playlists.map { if (it.id == p.id) it.copy(tracks = it.tracks + t) else it })
        message = "Added to “${p.name}”"
    }

    fun removeFromPlaylist(p: Playlist, t: Track) =
        savePlaylists(playlists.map { if (it.id == p.id) it.copy(tracks = it.tracks.filter { x -> x.id != t.id }) else it })

    fun deletePlaylist(p: Playlist) = savePlaylists(playlists.filter { it.id != p.id })

    // ---- share a playlist as a link / code (song names only; the receiver needs the same songs) ----
    fun shareLink(p: Playlist): String {
        val data = SharedPlaylist(p.name, p.tracks.map { SharedItem(it.title, it.artist) })
        val code = Base64.encodeToString(
            Store.json.encodeToString(SharedPlaylist.serializer(), data).toByteArray(),
            Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING,
        )
        return "moonplay://playlist/$code"
    }

    fun importShared(codeOrLink: String) {
        scope.launch {
            val code = codeOrLink.trim().substringAfterLast('/')
            val shared = runCatching {
                Store.json.decodeFromString(
                    SharedPlaylist.serializer(),
                    String(Base64.decode(code, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)),
                )
            }.getOrNull()
            if (shared == null) { message = "That share code isn't valid."; return@launch }
            if (songs.isEmpty() && hasPermission) songs = Library.scan(appContext)
            val found = shared.i.mapNotNull { s ->
                songs.firstOrNull { it.title.equals(s.t, true) && (it.artist.equals(s.a, true) || it.artist == "Unknown artist") }
                    ?: songs.firstOrNull { it.title.equals(s.t, true) }
            }.distinctBy { it.id }
            savePlaylists(playlists + Playlist(UUID.randomUUID().toString(), shared.n, found))
            message = "Added “${shared.n}”: found ${found.size} of ${shared.i.size} songs on this phone"
        }
    }
}
