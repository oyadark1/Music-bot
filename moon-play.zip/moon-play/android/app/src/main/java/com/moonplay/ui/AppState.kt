package com.moonplay.ui

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import com.moonplay.data.*
import com.moonplay.island.LyricsStore
import com.moonplay.player.Playback
import kotlinx.coroutines.delay
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject

/** Single source of truth for the UI (kept deliberately simple). */
object App {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    lateinit var downloads: Downloads
    private var socket: Socket? = null

    var user by mutableStateOf<User?>(null)
    var error by mutableStateOf<String?>(null)

    var results by mutableStateOf<List<Track>>(emptyList())
    var recent = mutableStateListOf<Track>()
    var playlists by mutableStateOf<List<Playlist>>(emptyList())
    var friends by mutableStateOf(Friends())
    var messages = mutableStateListOf<ChatMessage>()
    var downloaded = mutableStateListOf<String>() // track keys

    // player mirror
    var nowPlaying by mutableStateOf<Track?>(null)
    var isPlaying by mutableStateOf(false)
    var positionMs by mutableStateOf(0L)
    var lyrics by mutableStateOf<Lyrics?>(null)

    private lateinit var prefs: android.content.SharedPreferences
    private val sessionJson = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
    var pendingShare by mutableStateOf<String?>(null) // from a moonplay://playlist/<code> link

    fun init(context: Context) {
        if (::downloads.isInitialized) return
        downloads = Downloads(context.applicationContext)
        prefs = context.applicationContext.getSharedPreferences("moonplay", Context.MODE_PRIVATE)
        // Stay signed in across app restarts
        val token = prefs.getString("token", null)
        val saved = prefs.getString("user", null)?.let { runCatching { sessionJson.decodeFromString(User.serializer(), it) }.getOrNull() }
        if (token != null && saved != null) {
            Api.token = token; user = saved
            refreshAll(); connectSocket(token)
        }
    }

    fun signOut() {
        socket?.disconnect(); socket = null
        prefs.edit().clear().apply()
        Api.token = null; user = null
        playlists = emptyList(); friends = Friends(); messages.clear(); recent.clear()
    }

    private var bound = false

    fun bindPlayer() {
        if (bound) return
        scope.launch {
            var tries = 0
            while (Playback.player == null && tries++ < 50) delay(200) // service starts asynchronously
            val p = Playback.player ?: return@launch
            if (bound) return@launch
            bound = true
            isPlaying = p.isPlaying
            p.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                nowPlaying = Playback.currentTrack()
                nowPlaying?.let { t -> recent.removeAll { it.key == t.key }; recent.add(0, t); loadLyrics(t) }
            }
            })
        }
    }

    fun loadLyrics(t: Track, variant: String = "original", index: Int = 0) {
        lyrics = null
        LyricsStore.index = index // the floating island follows the same version
        scope.launch {
            runCatching { Api.service.lyrics(t.title, t.artist, variant, "en", index, t.durationMs) }.onSuccess { lyrics = it }
        }
    }

    /** "Different lyrics": flip to the next version the provider has for this song. */
    fun nextLyricsVersion() {
        val t = nowPlaying ?: return
        val l = lyrics ?: return
        if (l.count > 1) loadLyrics(t, LyricsStore.variant, (l.index + 1) % l.count)
    }

    // ---- auth ----
    fun auth(register: Boolean, username: String, password: String) = scope.launch {
        error = null
        runCatching {
            val c = Credentials(username, password)
            if (register) Api.service.register(c) else Api.service.login(c)
        }.onSuccess { r ->
            Api.token = r.token; user = r.user
            prefs.edit().putString("token", r.token).putString("user", sessionJson.encodeToString(User.serializer(), r.user)).apply()
            refreshAll(); connectSocket(r.token)
        }.onFailure { error = "Couldn't sign in. Check your details and server." }
    }

    fun refreshAll() = scope.launch {
        runCatching { playlists = Api.service.playlists() }
        runCatching { friends = Api.service.friends() }
        runCatching { results = Api.service.search("") }
    }

    fun search(q: String) = scope.launch { runCatching { results = Api.service.search(q) } }

    // ---- playback ----
    fun play(list: List<Track>, index: Int) {
        val track = list.getOrNull(index) ?: return
        if (track.streamUrl.isEmpty() && downloads.localUri(track) == null) {
            error = "“${track.title}” has no audio. Add a Jamendo key on the server for full songs."
            return
        }
        scope.launch {
            var tries = 0
            while (Playback.player == null && tries++ < 25) delay(200) // first tap can beat the service
            Playback.playQueue(list, index) { downloads.localUri(it) }
        }
        nowPlaying = track
        loadLyrics(track)
    }

    fun download(t: Track) = scope.launch {
        downloads.download(t).onSuccess { downloaded.add(t.key) }.onFailure { error = it.message }
    }

    // ---- playlists ----
    fun createPlaylist(name: String) = scope.launch {
        runCatching { Api.service.createPlaylist(NewPlaylist(name)) }.onSuccess { playlists = playlists + it }
    }
    fun addToPlaylist(p: Playlist, t: Track) = scope.launch {
        runCatching { Api.service.addTrack(p.id, t) }.onSuccess { upd -> playlists = playlists.map { if (it.id == upd.id) upd else it } }
    }
    fun deletePlaylist(p: Playlist) = scope.launch {
        runCatching { Api.service.deletePlaylist(p.id) }.onSuccess { playlists = playlists.filter { it.id != p.id } }
    }
    fun shareLink(p: Playlist) = "moonplay://playlist/${p.shareCode}"
    fun saveShared(code: String) = scope.launch {
        runCatching { Api.service.saveShared(code) }
            .onSuccess { playlists = playlists + it; error = "Added “${it.name}” to your library" }
            .onFailure { error = "Couldn't add that playlist. Check the share code." }
    }
    fun shareWith(p: Playlist, f: User) = scope.launch { runCatching { Api.service.shareWithFriend(p.id, f.id) } }

    // ---- friends & chat ----
    var userResults by mutableStateOf<List<User>>(emptyList())
    fun searchUsers(q: String) = scope.launch { runCatching { userResults = Api.service.searchUsers(q) } }
    fun addFriend(u: User) = scope.launch { runCatching { Api.service.requestFriend(u.id) }; refreshAll() }
    fun accept(r: FriendRequest) = scope.launch { runCatching { Api.service.acceptFriend(r.id) }; refreshAll() }

    fun openChat(friend: User) = scope.launch {
        messages.clear()
        runCatching { Api.service.chatHistory(friend.id) }.onSuccess { messages.addAll(it) }
    }

    /** Drop a playlist card into the chat; the friend can tap it to add the playlist to their library. */
    fun sendPlaylist(to: User, p: Playlist) {
        socket?.emit("message", JSONObject().put("to", to.id).put("text", "Check out my playlist “${p.name}” 🌙")
            .put("attachment", JSONObject().put("type", "playlist").put("shareCode", p.shareCode).put("name", p.name)))
    }

    fun send(to: User, text: String) {
        socket?.emit("message", JSONObject().put("to", to.id).put("text", text))
    }

    private fun connectSocket(token: String) {
        socket?.disconnect()
        val opts = IO.Options().apply { auth = mapOf("token" to token) }
        socket = IO.socket(com.moonplay.BuildConfig.API_BASE, opts).apply {
            on("message") { args ->
                val o = args[0] as JSONObject
                val m = ChatMessage(
                    o.getString("id"), o.getString("from"), o.getString("to"), o.optString("text"), o.optLong("at"),
                    o.optJSONObject("attachment")?.let { Attachment(it.optString("type", "playlist"), it.optString("shareCode"), it.optString("name")) },
                )
                scope.launch { messages.add(m) }
            }
            connect()
        }
    }
}
