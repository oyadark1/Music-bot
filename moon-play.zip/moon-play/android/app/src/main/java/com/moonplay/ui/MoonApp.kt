package com.moonplay.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.moonplay.player.Playback

@Composable
fun MoonApp(pendingShareCode: String?) {
    MoonTheme {
        var splash by remember { mutableStateOf(true) }
        if (splash) SplashScreen { splash = false } else Shell(pendingShareCode)
    }
}

@Composable
private fun Shell(pendingShareCode: String?) {
    val ctx = LocalContext.current
    val nav = rememberNavController()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val snack = remember { SnackbarHostState() }
    val audioPermission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    val askPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        App.hasPermission = granted
        if (granted) App.refreshLibrary()
    }

    LaunchedEffect(Unit) {
        App.bindPlayer()
        App.hasPermission = ContextCompat.checkSelfPermission(ctx, audioPermission) == PackageManager.PERMISSION_GRANTED
        if (App.hasPermission) App.refreshLibrary() else askPermission.launch(audioPermission)
        pendingShareCode?.let { App.importShared(it) }
    }
    LaunchedEffect(App.pendingShare) { App.pendingShare?.let { App.importShared(it); App.pendingShare = null } }
    LaunchedEffect(App.message) { App.message?.let { snack.showSnackbar(it); App.message = null } }

    val tabs = listOf(
        Triple("home", "Home", Icons.Filled.Home),
        Triple("library", "Library", Icons.Filled.LibraryMusic),
    )
    val fullScreen = route == "player" || route?.startsWith("playlist") == true

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            if (!fullScreen) Column {
                App.nowPlaying?.let { MiniPlayer { nav.navigate("player") } }
                NavigationBar(containerColor = Color.White) {
                    tabs.forEach { (r, label, icon) ->
                        NavigationBarItem(route == r, { nav.navigate(r) { launchSingleTop = true } }, { Icon(icon, null) }, label = { Text(label) })
                    }
                }
            }
        },
    ) { pad ->
        val allow = { askPermission.launch(audioPermission) }
        NavHost(nav, "home", Modifier.padding(bottom = pad.calculateBottomPadding())) {
            composable("home") { HomeScreen(onOpenPlaylist = { nav.navigate("playlist/$it") }, onAllow = allow) }
            composable("library") { LibraryScreen(onOpenPlaylist = { nav.navigate("playlist/$it") }, onAllow = allow) }
            composable("playlist/{id}") { PlaylistScreen(it.arguments?.getString("id").orEmpty()) { nav.popBackStack() } }
            composable("player") { NowPlayingScreen { nav.popBackStack() } }
        }
    }
}

@Composable
private fun MiniPlayer(onClick: () -> Unit) {
    val t = App.nowPlaying ?: return
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(22.dp)).background(Moon.Lavender.copy(alpha = .35f))
            .clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(t.artwork, 40)
        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text(t.title, fontWeight = FontWeight.SemiBold, maxLines = 1, fontSize = 14.sp)
            Text(t.artist, color = Moon.Muted, maxLines = 1, fontSize = 11.sp)
        }
        IconButton({ Playback.toggle() }) { Icon(if (App.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null) }
    }
}
