package com.moonplay.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.moonplay.data.User
import com.moonplay.player.Playback

@Composable
fun MoonApp(pendingShareCode: String?) {
    MoonTheme {
        var splash by remember { mutableStateOf(true) }
        when {
            splash && App.user == null -> SplashScreen { splash = false }
            App.user == null -> AuthScreen()
            else -> Shell(pendingShareCode)
        }
    }
}

@Composable
private fun Shell(pendingShareCode: String?) {
    val nav = rememberNavController()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    var chatWith by remember { mutableStateOf<User?>(null) }

    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { App.bindPlayer(); pendingShareCode?.let { App.saveShared(it) } }
    LaunchedEffect(App.pendingShare) { App.pendingShare?.let { App.saveShared(it); App.pendingShare = null } }
    LaunchedEffect(App.error) { App.error?.let { snack.showSnackbar(it); App.error = null } }

    val tabs = listOf(
        Triple("home", "Home", Icons.Filled.Home),
        Triple("friends", "Friends", Icons.Filled.People),
        Triple("library", "Library", Icons.Filled.LibraryMusic),
    )
    val fullScreen = route == "player" || route?.startsWith("chat") == true || route?.startsWith("playlist") == true

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            if (!fullScreen) Column {
                App.nowPlaying?.let { MiniPlayer { nav.navigate("player") } }
                NavigationBar(containerColor = Color.White) {
                    tabs.forEach { (r, label, icon) ->
                        NavigationBarItem(route == r, { nav.navigate(r) { launchSingleTop = true } }, { Icon(icon, null) }, label = { Text(label) })
                    }
                }
            }
        },
    ) { pad ->
        NavHost(nav, "home", Modifier.padding(bottom = pad.calculateBottomPadding())) {
            composable("home") { HomeScreen { nav.navigate("playlist/$it") } }
            composable("friends") { FriendsScreen { chatWith = it; nav.navigate("chat") } }
            composable("library") { LibraryScreen { nav.navigate("playlist/$it") } }
            composable("playlist/{id}") { PlaylistScreen(it.arguments?.getString("id").orEmpty()) { nav.popBackStack() } }
            composable("player") { NowPlayingScreen { nav.popBackStack() } }
            composable("chat") { chatWith?.let { f -> ChatScreen(f) { nav.popBackStack() } } }
        }
    }
}

@Composable
private fun MiniPlayer(onClick: () -> Unit) {
    val t = App.nowPlaying ?: return
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(22.dp)).background(Moon.Lavender.copy(alpha = .35f))
            .clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(t.artwork, 40)
        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text(t.title, fontWeight = FontWeight.SemiBold, maxLines = 1, fontSize = 14.sp)
            Text(t.artist, color = Moon.Muted, maxLines = 1, fontSize = 11.sp)
        }
        IconButton({ Playback.toggle() }) { Icon(if (App.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null) }
    }
}
