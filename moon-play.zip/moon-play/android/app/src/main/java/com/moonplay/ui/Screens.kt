package com.moonplay.ui

import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.moonplay.data.*
import com.moonplay.player.Playback
import kotlinx.coroutines.delay

// ---------- shared bits ----------

@Composable
fun Artwork(url: String, size: Int, seed: Int = 0, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(14.dp)
    val tints = listOf(Color(0xFF6F5BD0), Color(0xFFF2A8E0), Color(0xFF7FB2F5), Color(0xFFB9A6F0))
    Box(
        modifier.size(size.dp).clip(shape)
            .background(Brush.linearGradient(listOf(tints[seed % 4], tints[(seed + 1) % 4]))),
        contentAlignment = Alignment.Center,
    ) {
        if (url.isNotEmpty()) AsyncImage(url, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Filled.NightsStay, null, tint = Color.White.copy(alpha = .9f), modifier = Modifier.size((size / 2).dp))
    }
}

@Composable
fun Crescent(modifier: Modifier = Modifier) {
    androidx.compose.foundation.Canvas(modifier) {
        val r = size.minDimension / 2
        val c = Offset(size.width / 2, size.height / 2)
        val moon = Path().apply { addOval(androidx.compose.ui.geometry.Rect(c, r)) }
        val bite = Path().apply { addOval(androidx.compose.ui.geometry.Rect(Offset(c.x + r * .45f, c.y - r * .1f), r * .85f)) }
        val crescent = Path.combine(androidx.compose.ui.graphics.PathOperation.Difference, moon, bite)
        drawPath(crescent, Brush.linearGradient(listOf(Color(0xFFEDE5FF), Color(0xFFC9B6F7), Color(0xFFF2C3E8))))
    }
}

// ---------- splash + auth ----------

@Composable
fun SplashScreen(onStart: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Moon.SplashGradient)) {
        Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(80.dp))
            Crescent(Modifier.size(200.dp))
            Spacer(Modifier.height(24.dp))
            Text("Moon", fontSize = 56.sp, fontWeight = FontWeight.Light, color = Color.White)
            Text("P L A Y", fontSize = 20.sp, color = Color.White.copy(alpha = .75f))
            Spacer(Modifier.height(8.dp))
            Text("Your world. Your music.", color = Color.White.copy(alpha = .9f))
            Spacer(Modifier.weight(1f))
            Button(
                onClick = onStart,
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Moon.Ink),
                modifier = Modifier.fillMaxWidth(.8f).height(52.dp),
            ) { Text("Let's Play  +", fontWeight = FontWeight.SemiBold) }
            Spacer(Modifier.height(48.dp))
        }
    }
}

@Composable
fun AuthScreen() {
    var register by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().background(Moon.SplashGradient).padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Crescent(Modifier.size(110.dp))
        Spacer(Modifier.height(16.dp))
        Text(if (register) "Create account" else "Welcome back", fontSize = 26.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(username, { username = it }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            colors = fieldColors())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(password, { password = it }, label = { Text("Password") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            visualTransformation = PasswordVisualTransformation(), colors = fieldColors())
        App.error?.let { Text(it, color = Color(0xFF7A1E4A), modifier = Modifier.padding(top = 8.dp)) }
        Spacer(Modifier.height(18.dp))
        Button(
            { App.auth(register, username.trim(), password) },
            shape = CircleShape, modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Moon.Ink),
        ) { Text(if (register) "Sign up" else "Sign in") }
        TextButton({ register = !register }) {
            Text(if (register) "I already have an account" else "New here? Create an account", color = Color.White)
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedContainerColor = Color.White.copy(alpha = .55f), unfocusedContainerColor = Color.White.copy(alpha = .4f),
    focusedBorderColor = Color.White, unfocusedBorderColor = Color.White.copy(alpha = .6f),
    focusedTextColor = Moon.Ink, unfocusedTextColor = Moon.Ink,
    focusedLabelColor = Moon.Ink, unfocusedLabelColor = Moon.Ink,
)

// ---------- home ----------

@Composable
fun HomeScreen(onOpenPlaylist: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    LaunchedEffect(query) { delay(300); App.search(query) }

    LazyColumn(Modifier.fillMaxSize().background(Moon.PlayerGradient), contentPadding = PaddingValues(20.dp, 16.dp, 20.dp, 140.dp)) {
        item {
            Text("Moon", fontSize = 26.sp, fontWeight = FontWeight.Light, color = Moon.Violet, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Text("Good evening, ${App.user?.name ?: ""} ✦", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Let's vibe to something amazing", color = Moon.Muted)
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                query, { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search songs, artists, playlists...") },
                trailingIcon = { Icon(Icons.Filled.Search, null) },
                shape = CircleShape,
                colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                    unfocusedBorderColor = Color.Transparent, focusedBorderColor = Moon.Violet),
            )
            Spacer(Modifier.height(20.dp))
            Text("For You", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(10.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(App.playlists.size) { i ->
                    val p = App.playlists[i]
                    Column(Modifier.clickable { onOpenPlaylist(p.id) }) {
                        Artwork(p.tracks.firstOrNull()?.artwork.orEmpty(), 110, i)
                        Text(p.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                        Text("Playlist", fontSize = 11.sp, color = Moon.Muted)
                    }
                }
            }
            if (App.playlists.isEmpty()) Text("Create your first playlist in Library ✦", color = Moon.Muted)
            Spacer(Modifier.height(22.dp))
            Text(if (query.isBlank()) "Recently Played" else "Results", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
        }
        val list = if (query.isBlank() && App.recent.isNotEmpty()) App.recent.toList() else App.results
        items(list.size) { i -> TrackRow(list[i], list, i) }
    }
}

@Composable
fun TrackRow(t: Track, queue: List<Track>, index: Int) {
    var menu by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().clickable { App.play(queue, index) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Artwork(t.artwork, 48, index)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(t.title, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(t.artist, fontSize = 12.sp, color = Moon.Muted, maxLines = 1)
        }
        if (t.key in App.downloaded || App.downloads.isDownloaded(t)) Icon(Icons.Filled.DownloadDone, null, tint = Moon.Violet)
        Box {
            IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, null, tint = Moon.Muted) }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem({ Text("Download") }, { menu = false; App.download(t) })
                App.playlists.forEach { p ->
                    DropdownMenuItem({ Text("Add to ${p.name}") }, { menu = false; App.addToPlaylist(p, t) })
                }
            }
        }
    }
}

// ---------- playlist detail (dark) ----------

@Composable
fun PlaylistScreen(id: String, onBack: () -> Unit) {
    val p = App.playlists.firstOrNull { it.id == id } ?: return
    val ctx = androidx.compose.ui.platform.LocalContext.current
    LazyColumn(Modifier.fillMaxSize().background(Moon.NightGradient), contentPadding = PaddingValues(20.dp, 16.dp, 20.dp, 140.dp)) {
        item {
            IconButton(onBack) { Icon(Icons.Filled.ArrowBack, null, tint = Color.White) }
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Artwork(p.tracks.firstOrNull()?.artwork.orEmpty(), 200) }
            Spacer(Modifier.height(14.dp))
            Text(p.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("${p.tracks.size} songs", color = Color.White.copy(alpha = .7f))
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    { if (p.tracks.isNotEmpty()) App.play(p.tracks, 0) },
                    shape = CircleShape, modifier = Modifier.weight(1f).height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Moon.Lavender, contentColor = Moon.Night),
                ) { Icon(Icons.Filled.PlayArrow, null); Text("Play All") }
                FilledTonalIconButton({
                    val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(android.content.Intent.EXTRA_TEXT, "Listen to \"${p.name}\" on Moon Play: ${App.shareLink(p)}")
                    }
                    ctx.startActivity(android.content.Intent.createChooser(send, "Share playlist"))
                }) { Icon(Icons.Filled.Share, null) }
            }
            Spacer(Modifier.height(10.dp))
        }
        items(p.tracks.size) { i ->
            val t = p.tracks[i]
            Row(Modifier.fillMaxWidth().clickable { App.play(p.tracks, i) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${i + 1}", color = Color.White.copy(alpha = .6f), modifier = Modifier.width(28.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.title, color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text(t.artist, color = Color.White.copy(alpha = .6f), fontSize = 12.sp)
                }
                IconButton({ App.download(t) }) { Icon(Icons.Filled.Download, null, tint = Color.White.copy(alpha = .8f)) }
            }
        }
        // collaborators: share with friends directly
        item {
            Spacer(Modifier.height(12.dp))
            Text("Share with friends", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Send in chat, or make them a collaborator who can add songs", color = Color.White.copy(alpha = .6f), fontSize = 12.sp)
            App.friends.friends.forEach { f ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(f.name.ifEmpty { f.username }, color = Color.White, modifier = Modifier.weight(1f))
                    TextButton({ App.sendPlaylist(f, p) }) { Text("Send", color = Moon.Lavender) }
                    TextButton({ App.shareWith(p, f) }) { Text("+ Collaborator", color = Moon.Lavender) }
                }
            }
            if (p.ownerId == App.user?.id) {
                TextButton({ App.deletePlaylist(p); onBack() }, Modifier.padding(top = 12.dp)) { Text("Delete playlist", color = Moon.Pink) }
            }
        }
    }
}

// ---------- now playing (vinyl) ----------

@Composable
fun NowPlayingScreen(onBack: () -> Unit) {
    val t = App.nowPlaying
    var shuffle by remember { mutableStateOf(false) }
    var repeat by remember { mutableStateOf(false) }
    var variant by remember { mutableStateOf("original") }
    val spin = androidx.compose.animation.core.rememberInfiniteTransition(label = "spin")
    val angle by spin.animateFloat(0f, 360f, androidx.compose.animation.core.infiniteRepeatable(
        androidx.compose.animation.core.tween(9000, easing = androidx.compose.animation.core.LinearEasing)), label = "a")

    // keep position ticking
    LaunchedEffect(Unit) { while (true) { App.positionMs = Playback.player?.currentPosition ?: 0; delay(250) } }

    Column(Modifier.fillMaxSize().background(Moon.PlayerGradient).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Filled.KeyboardArrowDown, null) }
            Text("Playing from Moon Play", Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 13.sp, color = Moon.Muted)
            IconButton({ t?.let(App::download) }) { Icon(Icons.Filled.Download, null) }
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.size(260.dp).rotate(if (App.isPlaying) angle else 0f).clip(CircleShape)
            .background(Brush.sweepGradient(listOf(Color(0xFFD9C8FA), Color(0xFFF2A8E0), Color(0xFF9F86F0), Color(0xFFD9C8FA)))),
            contentAlignment = Alignment.Center) {
            Box(Modifier.size(110.dp).clip(CircleShape).background(Moon.Night), contentAlignment = Alignment.Center) {
                Crescent(Modifier.size(56.dp))
            }
        }
        Spacer(Modifier.height(18.dp))
        Text(t?.title ?: "Nothing playing", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(t?.artist ?: "", color = Moon.Muted)
        Spacer(Modifier.height(10.dp))

        // synced lyrics, with different lyric versions
        val lines = App.lyrics?.synced.orEmpty()
        val idx = lines.indexOfLast { it.timeMs <= App.positionMs }
        Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            if (lines.isEmpty()) Text(App.lyrics?.plain?.takeIf { it.isNotBlank() }?.lines()?.take(4)?.joinToString("\n") ?: "No lyrics found",
                color = Moon.Muted, textAlign = TextAlign.Center, maxLines = 4)
            else for (i in (idx - 1)..(idx + 1)) lines.getOrNull(i)?.let {
                Text(it.text.ifBlank { "♪" }, textAlign = TextAlign.Center,
                    fontSize = if (i == idx) 20.sp else 14.sp, fontWeight = if (i == idx) FontWeight.Bold else FontWeight.Normal,
                    color = if (i == idx) Moon.Ink else Moon.Muted, modifier = Modifier.padding(vertical = 3.dp))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val l = App.lyrics
            // More than one lyric version for this song: tap to flip to the next one
            if (l != null && l.count > 1) {
                AssistChip({ App.nextLyricsVersion() }, { Text("Lyrics ${l.index + 1}/${l.count} · tap for another") })
            }
            // Translations are only offered by Musixmatch
            if (l?.source == "musixmatch") listOf("original" to "Original", "translation" to "Translation").forEach { (v, label) ->
                FilterChip(variant == v, {
                    variant = v
                    com.moonplay.island.LyricsStore.variant = v
                    t?.let { App.loadLyrics(it, v) }
                }, { Text(label) })
            }
        }

        val dur = (t?.durationMs ?: 0L).coerceAtLeast(1L)
        Slider((App.positionMs.toFloat() / dur).coerceIn(0f, 1f), { Playback.player?.seekTo((it * dur).toLong()) })
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            IconButton({ shuffle = !shuffle; Playback.shuffle(shuffle) }) { Icon(Icons.Filled.Shuffle, null, tint = if (shuffle) Moon.Violet else Moon.Muted) }
            IconButton({ Playback.previous() }) { Icon(Icons.Filled.SkipPrevious, null, Modifier.size(34.dp)) }
            FilledIconButton({ Playback.toggle() }, Modifier.size(68.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Moon.Pink)) {
                Icon(if (App.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, Modifier.size(34.dp), tint = Color.White)
            }
            IconButton({ Playback.next() }) { Icon(Icons.Filled.SkipNext, null, Modifier.size(34.dp)) }
            IconButton({ repeat = !repeat; Playback.repeat(repeat) }) { Icon(Icons.Filled.Repeat, null, tint = if (repeat) Moon.Violet else Moon.Muted) }
        }
    }
}

// ---------- library ----------

@Composable
fun LibraryScreen(onOpenPlaylist: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var island by remember { mutableStateOf(com.moonplay.island.LyricsIslandService.hasPermission(ctx)) }
    LazyColumn(Modifier.fillMaxSize().background(Moon.PlayerGradient), contentPadding = PaddingValues(20.dp, 16.dp, 20.dp, 140.dp)) {
        item {
            Text("Library", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Lyrics Island", fontWeight = FontWeight.Bold)
                        Text("Live lyrics pill over any app", color = Moon.Muted, fontSize = 12.sp)
                    }
                    Switch(island && com.moonplay.island.LyricsIslandService.hasPermission(ctx), { on ->
                        if (on) {
                            if (!com.moonplay.island.LyricsIslandService.hasPermission(ctx)) com.moonplay.island.LyricsIslandService.requestPermission(ctx)
                            else { com.moonplay.island.LyricsIslandService.start(ctx); island = true }
                        } else { com.moonplay.island.LyricsIslandService.stop(ctx); island = false }
                    })
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(name, { name = it }, label = { Text("New playlist") }, singleLine = true, modifier = Modifier.weight(1f))
                IconButton({ if (name.isNotBlank()) { App.createPlaylist(name.trim()); name = "" } }) { Icon(Icons.Filled.Add, null) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(code, { code = it }, label = { Text("Paste a share code") }, singleLine = true, modifier = Modifier.weight(1f))
                IconButton({ if (code.isNotBlank()) { App.saveShared(code.trim().substringAfterLast('/')); code = "" } }) { Icon(Icons.Filled.Check, null) }
            }
            Spacer(Modifier.height(10.dp))
        }
        items(App.playlists.size) { i ->
            val p = App.playlists[i]
            Row(Modifier.fillMaxWidth().clickable { onOpenPlaylist(p.id) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Artwork(p.tracks.firstOrNull()?.artwork.orEmpty(), 56, i)
                Column(Modifier.padding(start = 12.dp)) {
                    Text(p.name, fontWeight = FontWeight.SemiBold)
                    Text("${p.tracks.size} songs", color = Moon.Muted, fontSize = 12.sp)
                }
            }
        }
    }
}
