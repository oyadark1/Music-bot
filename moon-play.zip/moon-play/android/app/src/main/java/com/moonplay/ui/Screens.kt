package com.moonplay.ui

import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.moonplay.data.*
import com.moonplay.player.Playback
import kotlinx.coroutines.delay

// ---------- shared bits ----------

@Composable
fun Artwork(url: String, size: Int, seed: Int = 0, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(14.dp)
    val tints = listOf(Color(0xFF6F5BD0), Color(0xFFF2A8E0), Color(0xFF7FB2F5), Color(0xFFB9A6F0))
    Box(
        modifier.size(size.dp).clip(shape)
            .background(Brush.linearGradient(listOf(tints[seed % 4], tints[(seed + 1) % 4]))),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Filled.NightsStay, null, tint = Color.White.copy(alpha = .9f), modifier = Modifier.size((size / 2).dp))
        if (url.isNotEmpty()) AsyncImage(url, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

@Composable
fun Crescent(modifier: Modifier = Modifier) {
    androidx.compose.foundation.Canvas(modifier) {
        val r = size.minDimension / 2
        val c = Offset(size.width / 2, size.height / 2)
        val moon = Path().apply { addOval(androidx.compose.ui.geometry.Rect(c, r)) }
        val bite = Path().apply { addOval(androidx.compose.ui.geometry.Rect(Offset(c.x + r * .45f, c.y - r * .1f), r * .85f)) }
        val crescent = Path.combine(androidx.compose.ui.graphics.PathOperation.Difference, moon, bite)
        drawPath(crescent, Brush.linearGradient(listOf(Color(0xFFEDE5FF), Color(0xFFC9B6F7), Color(0xFFF2C3E8))))
    }
}

// ---------- splash ----------

@Composable
fun SplashScreen(onStart: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Moon.SplashGradient)) {
        Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(80.dp))
            Crescent(Modifier.size(200.dp))
            Spacer(Modifier.height(24.dp))
            Text("Moon", fontSize = 56.sp, fontWeight = FontWeight.Light, color = Color.White)
            Text("P L A Y", fontSize = 20.sp, color = Color.White.copy(alpha = .75f))
            Spacer(Modifier.height(8.dp))
            Text("Your world. Your music.", color = Color.White.copy(alpha = .9f))
            Spacer(Modifier.weight(1f))
            Button(
                onClick = onStart,
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Moon.Ink),
                modifier = Modifier.fillMaxWidth(.8f).height(52.dp),
            ) { Text("Let's Play  +", fontWeight = FontWeight.SemiBold) }
            Spacer(Modifier.height(48.dp))
        }
    }
}

// ---------- home ----------

@Composable
fun HomeScreen(onOpenPlaylist: (String) -> Unit, onAllow: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val hour = remember { java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) }
    val greeting = when { hour < 12 -> "Good morning"; hour < 18 -> "Good afternoon"; else -> "Good evening" }
    val q = query.trim()
    val list = remember(App.songs, q) {
        if (q.isEmpty()) App.songs
        else App.songs.filter { it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true) }
    }

    LazyColumn(Modifier.fillMaxSize().background(Moon.PlayerGradient), contentPadding = PaddingValues(20.dp, 16.dp, 20.dp, 140.dp)) {
        item {
            Text("Moon", fontSize = 26.sp, fontWeight = FontWeight.Light, color = Moon.Violet, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Text("$greeting ✦", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Let's vibe to something amazing", color = Moon.Muted)
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                query, { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search songs, artists, albums...") },
                trailingIcon = { Icon(Icons.Filled.Search, null) },
                shape = CircleShape,
                colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                    unfocusedBorderColor = Color.Transparent, focusedBorderColor = Moon.Violet),
            )
            Spacer(Modifier.height(20.dp))
            if (!App.hasPermission) {
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Allow access to your music", fontWeight = FontWeight.Bold)
                        Text("Moon Play plays the songs stored on this phone. Nothing is uploaded.", color = Moon.Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(10.dp))
                        Button(onAllow, colors = ButtonDefaults.buttonColors(containerColor = Moon.Violet)) { Text("Allow") }
                    }
                }
                Spacer(Modifier.height(16.dp))
            } else if (App.songs.isEmpty() && !App.scanning) {
                Text("No music found on this phone yet. Copy some songs onto it, then tap Library → Rescan.", color = Moon.Muted)
                Spacer(Modifier.height(16.dp))
            }
            if (q.isEmpty()) {
                Text("For You", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(App.playlists.size) { i ->
                        val p = App.playlists[i]
                        Column(Modifier.clickable { onOpenPlaylist(p.id) }) {
                            Artwork(p.tracks.firstOrNull()?.artwork.orEmpty(), 110, i)
                            Text(p.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp), maxLines = 1)
                            Text("${p.tracks.size} songs", fontSize = 11.sp, color = Moon.Muted)
                        }
                    }
                }
                if (App.playlists.isEmpty()) Text("Create your first playlist in Library ✦", color = Moon.Muted)
                Spacer(Modifier.height(22.dp))
                if (App.recent.isNotEmpty()) {
                    Text("Recently Played", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(6.dp))
                }
            }
        }
        if (q.isEmpty()) {
            val recent = App.recent.take(5)
            items(recent.size) { i -> TrackRow(recent[i], App.recent.toList(), i) }
            item { Text("All Songs (${App.songs.size})", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp)) }
        } else {
            item { Text("Results (${list.size})", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(bottom = 6.dp)) }
        }
        items(list.size) { i -> TrackRow(list[i], list, i) }
    }
}

@Composable
fun TrackRow(t: Track, queue: List<Track>, index: Int, onRemove: (() -> Unit)? = null) {
    var menu by remember { mutableStateOf(false) }
    var naming by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().clickable { App.play(queue, index) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Artwork(t.artwork, 48, index)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(t.title, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(t.artist, fontSize = 12.sp, color = Moon.Muted, maxLines = 1)
        }
        Box {
            IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, null, tint = Moon.Muted) }
            DropdownMenu(menu, { menu = false }) {
                App.playlists.forEach { p ->
                    DropdownMenuItem({ Text("Add to ${p.name}") }, { menu = false; App.addToPlaylist(p, t) })
                }
                DropdownMenuItem({ Text("New playlist…") }, { menu = false; naming = true })
                if (onRemove != null) DropdownMenuItem({ Text("Remove from this playlist") }, { menu = false; onRemove() })
            }
        }
    }
    if (naming) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { naming = false },
            title = { Text("New playlist") },
            text = { OutlinedTextField(name, { name = it }, label = { Text("Playlist name") }, singleLine = true) },
            confirmButton = { TextButton({ if (name.isNotBlank()) { App.createPlaylist(name.trim(), t); naming = false } }) { Text("Create") } },
            dismissButton = { TextButton({ naming = false }) { Text("Cancel") } },
        )
    }
}

// ---------- playlist detail (dark) ----------

@Composable
fun PlaylistScreen(id: String, onBack: () -> Unit) {
    val p = App.playlists.firstOrNull { it.id == id }
    if (p == null) { LaunchedEffect(Unit) { onBack() }; return }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    LazyColumn(Modifier.fillMaxSize().background(Moon.NightGradient), contentPadding = PaddingValues(20.dp, 16.dp, 20.dp, 140.dp)) {
        item {
            IconButton(onBack) { Icon(Icons.Filled.ArrowBack, null, tint = Color.White) }
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Artwork(p.tracks.firstOrNull()?.artwork.orEmpty(), 200) }
            Spacer(Modifier.height(14.dp))
            Text(p.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("${p.tracks.size} songs", color = Color.White.copy(alpha = .7f))
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    { if (p.tracks.isNotEmpty()) App.play(p.tracks, 0) },
                    shape = CircleShape, modifier = Modifier.weight(1f).height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Moon.Lavender, contentColor = Moon.Night),
                ) { Icon(Icons.Filled.PlayArrow, null); Text("Play All") }
                FilledTonalIconButton({
                    val link = App.shareLink(p)
                    val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(
                            android.content.Intent.EXTRA_TEXT,
                            "Listen to \"${p.name}\" on Moon Play 🌙\n$link\n\nOr paste this code in Moon Play → Library:\n${link.substringAfterLast('/')}",
                        )
                    }
                    ctx.startActivity(android.content.Intent.createChooser(send, "Share playlist"))
                }) { Icon(Icons.Filled.Share, null) }
                FilledTonalIconButton({ App.deletePlaylist(p); onBack() }) { Icon(Icons.Filled.Delete, null) }
            }
            Spacer(Modifier.height(10.dp))
            if (p.tracks.isEmpty()) Text("Empty. Use ⋮ on any song to add it here.", color = Color.White.copy(alpha = .7f))
        }
        items(p.tracks.size) { i ->
            val t = p.tracks[i]
            Row(Modifier.fillMaxWidth().clickable { App.play(p.tracks, i) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${i + 1}", color = Color.White.copy(alpha = .6f), modifier = Modifier.width(28.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    Text(t.artist, color = Color.White.copy(alpha = .6f), fontSize = 12.sp, maxLines = 1)
                }
                IconButton({ App.removeFromPlaylist(p, t) }) { Icon(Icons.Filled.Close, null, tint = Color.White.copy(alpha = .8f)) }
            }
        }
    }
}

// ---------- now playing (vinyl) ----------

@Composable
fun NowPlayingScreen(onBack: () -> Unit) {
    val t = App.nowPlaying
    var shuffle by remember { mutableStateOf(false) }
    var repeat by remember { mutableStateOf(false) }
    val spin = androidx.compose.animation.core.rememberInfiniteTransition(label = "spin")
    val angle by spin.animateFloat(0f, 360f, androidx.compose.animation.core.infiniteRepeatable(
        androidx.compose.animation.core.tween(9000, easing = androidx.compose.animation.core.LinearEasing)), label = "a")

    // keep position ticking
    LaunchedEffect(Unit) { while (true) { App.positionMs = Playback.player?.currentPosition ?: 0; delay(250) } }

    Column(Modifier.fillMaxSize().background(Moon.PlayerGradient).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Filled.KeyboardArrowDown, null) }
            Text("Playing from Moon Play", Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 13.sp, color = Moon.Muted)
            Spacer(Modifier.size(48.dp))
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.size(260.dp).rotate(if (App.isPlaying) angle else 0f).clip(CircleShape)
            .background(Brush.sweepGradient(listOf(Color(0xFFD9C8FA), Color(0xFFF2A8E0), Color(0xFF9F86F0), Color(0xFFD9C8FA)))),
            contentAlignment = Alignment.Center) {
            Box(Modifier.size(110.dp).clip(CircleShape).background(Moon.Night), contentAlignment = Alignment.Center) {
                if (t != null && t.artwork.isNotEmpty()) Artwork(t.artwork, 110) else Crescent(Modifier.size(56.dp))
            }
        }
        Spacer(Modifier.height(18.dp))
        Text(t?.title ?: "Nothing playing", fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(t?.artist ?: "", color = Moon.Muted, maxLines = 1)
        Spacer(Modifier.height(10.dp))

        // synced lyrics (saved on the phone after the first lookup)
        val l = App.lyrics
        val lines = l?.synced.orEmpty()
        val idx = lines.indexOfLast { it.timeMs <= App.positionMs }
        Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            when {
                t == null -> {}
                l == null -> Text("Finding lyrics…", color = Moon.Muted)
                lines.isNotEmpty() -> ((idx - 1)..(idx + 1)).forEach { i ->
                    lines.getOrNull(i)?.let {
                        Text(it.text.ifBlank { "♪" }, textAlign = TextAlign.Center,
                            fontSize = if (i == idx) 20.sp else 14.sp, fontWeight = if (i == idx) FontWeight.Bold else FontWeight.Normal,
                            color = if (i == idx) Moon.Ink else Moon.Muted, modifier = Modifier.padding(vertical = 3.dp))
                    }
                }
                l.plain.isNotBlank() -> Text(l.plain.lines().take(6).joinToString("\n"), color = Moon.Muted, textAlign = TextAlign.Center, maxLines = 6)
                else -> Text("No lyrics found. Connect to the internet once and they'll be saved for offline.", color = Moon.Muted, textAlign = TextAlign.Center)
            }
        }
        // More than one lyric version for this song: tap to flip to the next one
        if (l != null && l.count > 1) {
            AssistChip({ App.nextLyricsVersion() }, { Text("Lyrics ${l.index + 1}/${l.count} · tap for another") })
        }

        val dur = (t?.durationMs ?: 0L).coerceAtLeast(1L)
        Slider((App.positionMs.toFloat() / dur).coerceIn(0f, 1f), { Playback.player?.seekTo((it * dur).toLong()) })
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            IconButton({ shuffle = !shuffle; Playback.shuffle(shuffle) }) { Icon(Icons.Filled.Shuffle, null, tint = if (shuffle) Moon.Violet else Moon.Muted) }
            IconButton({ Playback.previous() }) { Icon(Icons.Filled.SkipPrevious, null, Modifier.size(34.dp)) }
            FilledIconButton({ Playback.toggle() }, Modifier.size(68.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Moon.Pink)) {
                Icon(if (App.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, Modifier.size(34.dp), tint = Color.White)
            }
            IconButton({ Playback.next() }) { Icon(Icons.Filled.SkipNext, null, Modifier.size(34.dp)) }
            IconButton({ repeat = !repeat; Playback.repeat(repeat) }) { Icon(Icons.Filled.Repeat, null, tint = if (repeat) Moon.Violet else Moon.Muted) }
        }
    }
}

// ---------- library ----------

@Composable
fun LibraryScreen(onOpenPlaylist: (String) -> Unit, onAllow: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var island by remember { mutableStateOf(com.moonplay.island.LyricsIslandService.hasPermission(ctx)) }
    LazyColumn(Modifier.fillMaxSize().background(Moon.PlayerGradient), contentPadding = PaddingValues(20.dp, 16.dp, 20.dp, 140.dp)) {
        item {
            Text("Library", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Lyrics Island", fontWeight = FontWeight.Bold)
                        Text("Live lyrics pill over any app", color = Moon.Muted, fontSize = 12.sp)
                    }
                    Switch(island && com.moonplay.island.LyricsIslandService.hasPermission(ctx), { on ->
                        if (on) {
                            if (!com.moonplay.island.LyricsIslandService.hasPermission(ctx)) com.moonplay.island.LyricsIslandService.requestPermission(ctx)
                            else { com.moonplay.island.LyricsIslandService.start(ctx); island = true }
                        } else { com.moonplay.island.LyricsIslandService.stop(ctx); island = false }
                    })
                }
            }
            Spacer(Modifier.height(12.dp))
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Music on this phone", fontWeight = FontWeight.Bold)
                        Text("${App.songs.size} songs" + if (App.scanning) " · scanning…" else "", color = Moon.Muted, fontSize = 12.sp)
                    }
                    TextButton({ if (App.hasPermission) App.refreshLibrary() else onAllow() }) { Text("Rescan", color = Moon.Violet) }
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(name, { name = it }, label = { Text("New playlist") }, singleLine = true, modifier = Modifier.weight(1f))
                IconButton({ if (name.isNotBlank()) { App.createPlaylist(name.trim()); name = "" } }) { Icon(Icons.Filled.Add, null) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(code, { code = it }, label = { Text("Paste a share code or link") }, singleLine = true, modifier = Modifier.weight(1f))
                IconButton({ if (code.isNotBlank()) { App.importShared(code); code = "" } }) { Icon(Icons.Filled.Check, null) }
            }
            Spacer(Modifier.height(10.dp))
            if (App.playlists.isEmpty()) Text("No playlists yet.", color = Moon.Muted)
        }
        items(App.playlists.size) { i ->
            val p = App.playlists[i]
            Row(Modifier.fillMaxWidth().clickable { onOpenPlaylist(p.id) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Artwork(p.tracks.firstOrNull()?.artwork.orEmpty(), 56, i)
                Column(Modifier.padding(start = 12.dp)) {
                    Text(p.name, fontWeight = FontWeight.SemiBold)
                    Text("${p.tracks.size} songs", color = Moon.Muted, fontSize = 12.sp)
                }
            }
        }
    }
}
