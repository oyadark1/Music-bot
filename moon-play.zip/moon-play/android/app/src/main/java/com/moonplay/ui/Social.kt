package com.moonplay.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.moonplay.data.User
import kotlinx.coroutines.delay

@Composable
fun FriendsScreen(onChat: (User) -> Unit) {
    var q by remember { mutableStateOf("") }
    LaunchedEffect(q) { if (q.length >= 2) { delay(300); App.searchUsers(q) } else App.userResults = emptyList() }
    LaunchedEffect(Unit) { App.refreshAll() }

    LazyColumn(Modifier.fillMaxSize().background(Moon.PlayerGradient), contentPadding = PaddingValues(20.dp, 16.dp, 20.dp, 140.dp)) {
        item {
            Text("Friends", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(q, { q = it }, label = { Text("Find people by username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        items(App.userResults) { u ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("@${u.username}", Modifier.weight(1f))
                FilledTonalButton({ App.addFriend(u) }) { Text("Add") }
            }
        }
        if (App.friends.incoming.isNotEmpty()) {
            item { Text("Requests", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp)) }
            items(App.friends.incoming) { r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("@${r.user.username}", Modifier.weight(1f))
                    Button({ App.accept(r) }) { Text("Accept") }
                }
            }
        }
        item { Text("Your friends", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp)) }
        items(App.friends.friends) { f ->
            Row(Modifier.fillMaxWidth().clickable { onChat(f) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(CircleShape).background(Moon.Lavender), contentAlignment = Alignment.Center) {
                    Text(f.username.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold)
                }
                Text("@${f.username}", Modifier.padding(start = 12.dp), fontWeight = FontWeight.SemiBold)
            }
        }
        if (App.friends.friends.isEmpty()) item { Text("No friends yet — search a username above ✦", color = Moon.Muted) }
        item { TextButton({ App.signOut() }, Modifier.padding(top = 16.dp)) { Text("Sign out", color = Moon.Muted) } }
    }
}

@Composable
fun ChatScreen(friend: User, onBack: () -> Unit) {
    var text by remember { mutableStateOf("") }
    LaunchedEffect(friend.id) { App.openChat(friend) }
    val me = App.user?.id

    Column(Modifier.fillMaxSize().background(Moon.PlayerGradient).imePadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Filled.ArrowBack, null) }
            Text("@${friend.username}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), reverseLayout = false) {
            items(App.messages.filter { it.from == friend.id || it.to == friend.id }) { m ->
                val mine = m.from == me
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                    Column(
                        Modifier.widthIn(max = 280.dp).clip(RoundedCornerShape(18.dp))
                            .background(if (mine) Moon.Violet else Color.White).padding(horizontal = 14.dp, vertical = 9.dp),
                    ) {
                        Text(m.text, color = if (mine) Color.White else Moon.Ink)
                        m.attachment?.takeIf { it.type == "playlist" && it.shareCode.isNotEmpty() }?.let { a ->
                            TextButton({ App.saveShared(a.shareCode) }, contentPadding = PaddingValues(0.dp)) {
                                Text("🎵 ${a.name} · Add to my library", color = if (mine) Color.White else Moon.Violet, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Message") }, shape = CircleShape, singleLine = true)
            IconButton({ if (text.isNotBlank()) { App.send(friend, text.trim()); text = "" } }) { Icon(Icons.Filled.Send, null, tint = Moon.Violet) }
        }
    }
}
