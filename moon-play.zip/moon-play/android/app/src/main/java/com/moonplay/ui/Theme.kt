package com.moonplay.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Palette taken from the Moon Play mockups
object Moon {
    val Lavender = Color(0xFFB9A6F0)
    val Violet = Color(0xFF8E73E8)
    val DeepViolet = Color(0xFF3B2F7A)
    val Night = Color(0xFF2B2260)
    val Mist = Color(0xFFF3EEFF)
    val Pink = Color(0xFFF2A8E0)
    val Ink = Color(0xFF2A2347)
    val Muted = Color(0xFF8B83A8)

    val SplashGradient = Brush.verticalGradient(listOf(Color(0xFFA48DF0), Color(0xFFD8C6F7), Color(0xFFF1D4EF)))
    val NightGradient = Brush.verticalGradient(listOf(Color(0xFF4A3C95), Color(0xFF2B2260)))
    val PlayerGradient = Brush.verticalGradient(listOf(Color(0xFFEFE8FF), Color(0xFFFBEFFA)))
    val Accent = Brush.horizontalGradient(listOf(Color(0xFFB58DF3), Color(0xFFF2A8E0)))
}

@Composable
fun MoonTheme(content: @Composable () -> Unit) {
    val colors = lightColorScheme(
        primary = Moon.Violet,
        secondary = Moon.Pink,
        background = Moon.Mist,
        surface = Color.White,
        onBackground = Moon.Ink,
        onSurface = Moon.Ink,
    )
    MaterialTheme(colorScheme = colors, content = content)
}
