import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { nanoid } from 'nanoid';
import { Router } from 'express';
import { db, save } from './db.js';

const SECRET = process.env.JWT_SECRET || 'dev-secret';

export const sign = (user) => jwt.sign({ id: user.id }, SECRET, { expiresIn: '30d' });
export const verify = (token) => jwt.verify(token, SECRET);

export function requireAuth(req, res, next) {
  const h = req.headers.authorization || '';
  try {
    const { id } = verify(h.replace('Bearer ', ''));
    const user = db.users.find((u) => u.id === id);
    if (!user) throw new Error('no user');
    req.user = user;
    next();
  } catch {
    res.status(401).json({ error: 'Unauthorized' });
  }
}

export const publicUser = (u) => ({ id: u.id, username: u.username, name: u.name });

const r = Router();

r.post('/register', async (req, res) => {
  const { username, password, name } = req.body || {};
  if (!username || !password || password.length < 6)
    return res.status(400).json({ error: 'username and password (6+ chars) required' });
  if (db.users.some((u) => u.username.toLowerCase() === username.toLowerCase()))
    return res.status(409).json({ error: 'Username taken' });
  const user = { id: nanoid(10), username, name: name || username, hash: await bcrypt.hash(password, 10) };
  db.users.push(user);
  save();
  res.json({ token: sign(user), user: publicUser(user) });
});

r.post('/login', async (req, res) => {
  const { username, password } = req.body || {};
  const user = db.users.find((u) => u.username.toLowerCase() === String(username).toLowerCase());
  if (!user || !(await bcrypt.compare(password || '', user.hash)))
    return res.status(401).json({ error: 'Invalid credentials' });
  res.json({ token: sign(user), user: publicUser(user) });
});

r.get('/me', requireAuth, (req, res) => res.json(publicUser(req.user)));

export default r;
