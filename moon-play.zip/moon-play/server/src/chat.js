import { Router } from 'express';
import { nanoid } from 'nanoid';
import { db, save } from './db.js';
import { requireAuth, verify } from './auth.js';
import { areFriends } from './friends.js';

const r = Router();

const convoKey = (a, b) => [a, b].sort().join(':');

// History with a friend
r.get('/:friendId', requireAuth, (req, res) => {
  if (!areFriends(req.user.id, req.params.friendId)) return res.status(403).json({ error: 'Not friends' });
  const key = convoKey(req.user.id, req.params.friendId);
  res.json(db.messages.filter((m) => m.convo === key).slice(-200));
});

export function attachChat(io) {
  io.use((socket, next) => {
    try {
      socket.userId = verify(socket.handshake.auth?.token).id;
      next();
    } catch {
      next(new Error('unauthorized'));
    }
  });

  io.on('connection', (socket) => {
    socket.join(`user:${socket.userId}`);

    // text message or a shared song/playlist card
    socket.on('message', ({ to, text, attachment }, ack) => {
      if (!to || (!text && !attachment) || !areFriends(socket.userId, to)) return ack?.({ error: 'not allowed' });
      const msg = {
        id: nanoid(10),
        convo: convoKey(socket.userId, to),
        from: socket.userId,
        to,
        text: String(text || '').slice(0, 2000),
        attachment: attachment || null, // { type: 'track'|'playlist', ... }
        at: Date.now(),
      };
      db.messages.push(msg);
      save();
      io.to(`user:${to}`).to(`user:${socket.userId}`).emit('message', msg);
      ack?.({ ok: true, message: msg });
    });

    socket.on('typing', ({ to }) => io.to(`user:${to}`).emit('typing', { from: socket.userId }));
  });
}

export default r;
