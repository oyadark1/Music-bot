// Tiny JSON-file store so the server runs with zero native deps.
// Swap for Postgres/Mongo later; every route only uses these helpers.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const file = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'data.json');
const empty = { users: [], playlists: [], friendships: [], messages: [] };

let state = fs.existsSync(file) ? { ...empty, ...JSON.parse(fs.readFileSync(file, 'utf8')) } : structuredClone(empty);

export const db = state;
export function save() {
  fs.writeFileSync(file, JSON.stringify(state, null, 2));
}
