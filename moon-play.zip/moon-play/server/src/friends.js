import { Router } from 'express';
import { nanoid } from 'nanoid';
import { db, save } from './db.js';
import { requireAuth, publicUser } from './auth.js';

const r = Router();
const byId = (id) => db.users.find((u) => u.id === id);

export function areFriends(a, b) {
  return db.friendships.some(
    (f) => f.status === 'accepted' && ((f.from === a && f.to === b) || (f.from === b && f.to === a))
  );
}

// Search users by username
r.get('/search', requireAuth, (req, res) => {
  const q = String(req.query.q || '').toLowerCase();
  if (q.length < 2) return res.json([]);
  res.json(
    db.users
      .filter((u) => u.id !== req.user.id && u.username.toLowerCase().includes(q))
      .slice(0, 20)
      .map(publicUser)
  );
});

// Friends + pending requests
r.get('/', requireAuth, (req, res) => {
  const me = req.user.id;
  const mine = db.friendships.filter((f) => f.from === me || f.to === me);
  res.json({
    friends: mine.filter((f) => f.status === 'accepted').map((f) => publicUser(byId(f.from === me ? f.to : f.from))),
    incoming: mine.filter((f) => f.status === 'pending' && f.to === me).map((f) => ({ id: f.id, user: publicUser(byId(f.from)) })),
    outgoing: mine.filter((f) => f.status === 'pending' && f.from === me).map((f) => ({ id: f.id, user: publicUser(byId(f.to)) })),
  });
});

r.post('/request/:userId', requireAuth, (req, res) => {
  const me = req.user.id;
  const other = req.params.userId;
  if (!byId(other) || other === me) return res.status(404).json({ error: 'User not found' });
  const existing = db.friendships.find(
    (f) => (f.from === me && f.to === other) || (f.from === other && f.to === me)
  );
  if (existing) {
    // They already asked us: accept automatically
    if (existing.status === 'pending' && existing.to === me) existing.status = 'accepted';
    save();
    return res.json(existing);
  }
  const f = { id: nanoid(8), from: me, to: other, status: 'pending', createdAt: Date.now() };
  db.friendships.push(f);
  save();
  res.status(201).json(f);
});

r.post('/accept/:requestId', requireAuth, (req, res) => {
  const f = db.friendships.find((x) => x.id === req.params.requestId && x.to === req.user.id);
  if (!f) return res.status(404).json({ error: 'Request not found' });
  f.status = 'accepted';
  save();
  res.json(f);
});

r.delete('/:userId', requireAuth, (req, res) => {
  const me = req.user.id;
  db.friendships = db.friendships.filter(
    (f) => !((f.from === me && f.to === req.params.userId) || (f.from === req.params.userId && f.to === me))
  );
  save();
  res.json({ ok: true });
});

export default r;
