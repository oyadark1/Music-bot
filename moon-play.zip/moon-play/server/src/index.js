import http from 'node:http';
import express from 'express';
import cors from 'cors';
import { Server } from 'socket.io';
import auth from './auth.js';
import playlists from './playlists.js';
import friends from './friends.js';
import music from './music.js';
import chat, { attachChat } from './chat.js';

export const app = express();
app.use(cors());
app.use(express.json());

app.get('/health', (_req, res) => res.json({ ok: true, app: 'Moon Play' }));
app.use('/auth', auth);
app.use('/music', music);
app.use('/playlists', playlists);
app.use('/friends', friends);
app.use('/chat', chat);

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
attachChat(io);

const port = process.env.PORT || 4000;
if (process.argv[1] && process.argv[1].endsWith('index.js')) {
  server.listen(port, () => console.log(`Moon Play server on :${port}`));
}
