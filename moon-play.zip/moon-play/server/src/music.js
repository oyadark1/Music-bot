// Catalog + lyrics routes.
//
// Catalog (first one configured wins):
//  1. Jamendo  (JAMENDO_CLIENT_ID)  - Creative Commons music: full-length streams, many downloadable
//  2. Spotify  (SPOTIFY_CLIENT_ID)  - metadata + 30 s previews only
//  3. built-in demo catalog (no audio) so the app runs end to end in development
//
// Lyrics:
//  - Musixmatch (MUSIXMATCH_API_KEY) if configured (commercial licence required)
//  - otherwise LRCLIB (open, no key) which often has SEVERAL lyric versions per song;
//    the app lets the user flip between them with ?index=
//  - otherwise original placeholder lyrics for the demo catalog
import { Router } from 'express';
import { requireAuth } from './auth.js';

const r = Router();
const UA = { 'User-Agent': 'MoonPlay/1.0 (https://github.com/moon-play)' };

const DEMO = [
  { id: 'demo-1', title: 'Dreamy Night', artist: 'Moon Play', album: 'Moon Sessions', durationMs: 30000, artwork: '', streamUrl: '', downloadUrl: '' },
  { id: 'demo-2', title: 'Night Changes (demo)', artist: 'Moon Play', album: 'Moon Sessions', durationMs: 30000, artwork: '', streamUrl: '', downloadUrl: '' },
  { id: 'demo-3', title: 'Sky Full of Stars (demo)', artist: 'Moon Play', album: 'Moon Sessions', durationMs: 30000, artwork: '', streamUrl: '', downloadUrl: '' },
];

// Original placeholder lyrics in LRC format ("[mm:ss.xx] line")
const DEMO_LRC = `[00:00.00]♪
[00:04.00]Moonlight on the windowsill
[00:09.00]The whole world's moving slow
[00:14.00]Clouds are drifting, hearts are still
[00:19.00]Follow where the quiet goes
[00:24.00]♪`;

// ---------- Jamendo ----------
const mapJamendo = (t) => ({
  id: `jm-${t.id}`,
  title: t.name,
  artist: t.artist_name,
  album: t.album_name || '',
  durationMs: (Number(t.duration) || 0) * 1000,
  artwork: t.image || t.album_image || '',
  streamUrl: t.audio || '',
  // only present when the artist's licence allows downloading
  downloadUrl: t.audiodownload_allowed ? t.audiodownload || '' : '',
});

async function jamendo(params) {
  const url = new URL('https://api.jamendo.com/v3.0/tracks/');
  const all = { client_id: process.env.JAMENDO_CLIENT_ID, format: 'json', limit: 30, imagesize: 400, audioformat: 'mp32', ...params };
  for (const [k, v] of Object.entries(all)) url.searchParams.set(k, v);
  const resp = await fetch(url, { headers: UA });
  if (!resp.ok) throw new Error(`Jamendo ${resp.status}`);
  const j = await resp.json();
  return (j.results || []).map(mapJamendo);
}

// ---------- Spotify ----------
let spotifyToken = { value: null, exp: 0 };
async function getSpotifyToken() {
  if (spotifyToken.value && Date.now() < spotifyToken.exp) return spotifyToken.value;
  const { SPOTIFY_CLIENT_ID: id, SPOTIFY_CLIENT_SECRET: secret } = process.env;
  const resp = await fetch('https://accounts.spotify.com/api/token', {
    method: 'POST',
    headers: {
      Authorization: 'Basic ' + Buffer.from(`${id}:${secret}`).toString('base64'),
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials',
  });
  const j = await resp.json();
  spotifyToken = { value: j.access_token, exp: Date.now() + (j.expires_in - 60) * 1000 };
  return spotifyToken.value;
}

async function spotifySearch(q) {
  const token = await getSpotifyToken();
  const resp = await fetch(`https://api.spotify.com/v1/search?type=track&limit=25&q=${encodeURIComponent(q)}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  const j = await resp.json();
  return (j.tracks?.items || []).map((t) => ({
    id: t.id,
    title: t.name,
    artist: t.artists.map((a) => a.name).join(', '),
    album: t.album.name,
    durationMs: t.duration_ms,
    artwork: t.album.images?.[0]?.url || '',
    streamUrl: t.preview_url || '', // 30s preview; use your licensed streaming source for full tracks
    downloadUrl: '',
  }));
}

// GET /music/search?q=   (empty q = what's popular right now)
r.get('/search', requireAuth, async (req, res) => {
  const q = String(req.query.q || '').trim();
  try {
    if (process.env.JAMENDO_CLIENT_ID) {
      return res.json(await jamendo(q ? { search: q } : { order: 'popularity_week' }));
    }
    if (process.env.SPOTIFY_CLIENT_ID && q) return res.json(await spotifySearch(q));
  } catch (e) {
    return res.status(502).json({ error: 'Catalog provider error' });
  }
  const ql = q.toLowerCase();
  res.json(DEMO.filter((t) => !ql || `${t.title} ${t.artist}`.toLowerCase().includes(ql)));
});

// GET /music/featured?tag=chill|pop|lofi|electronic|rock...   (Jamendo only)
r.get('/featured', requireAuth, async (req, res) => {
  if (!process.env.JAMENDO_CLIENT_ID) return res.json(DEMO);
  try {
    const params = { order: 'popularity_week' };
    if (req.query.tag) params.tags = String(req.query.tag);
    res.json(await jamendo(params));
  } catch {
    res.status(502).json({ error: 'Catalog provider error' });
  }
});

// ---------- Lyrics ----------
export function parseLrc(lrc) {
  const out = [];
  for (const line of lrc.split('\n')) {
    const m = line.match(/^\[(\d+):(\d+(?:\.\d+)?)\](.*)$/);
    if (m) out.push({ timeMs: Math.round((+m[1] * 60 + parseFloat(m[2])) * 1000), text: m[3].trim() });
  }
  return out.sort((a, b) => a.timeMs - b.timeMs);
}

/** Every LRCLIB version for a song, closest duration first, time-synced before plain text. */
async function lrclib(title, artist, durationMs) {
  const url = new URL('https://lrclib.net/api/search');
  url.searchParams.set('track_name', title);
  if (artist) url.searchParams.set('artist_name', artist);
  const resp = await fetch(url, { headers: UA });
  if (!resp.ok) return [];
  const list = await resp.json();
  const want = (Number(durationMs) || 0) / 1000;
  return list
    .filter((l) => l.syncedLyrics || l.plainLyrics)
    .sort(
      (a, b) =>
        Number(!!b.syncedLyrics) - Number(!!a.syncedLyrics) ||
        Math.abs((a.duration || 0) - want) - Math.abs((b.duration || 0) - want)
    )
    .map((l) => ({
      label: [l.trackName, l.artistName].filter(Boolean).join(' · '),
      synced: l.syncedLyrics ? parseLrc(l.syncedLyrics) : [],
      plain: l.plainLyrics || '',
    }));
}

// Lyrics: ?title=&artist=&durationMs=&index=0
//   -> { source, variant, index, count, label, synced: [{timeMs,text}], plain }
// "different lyrics": count > 1 means more versions exist; request them with ?index=1,2,...
// variant=translation&lang=hi is passed to Musixmatch when that provider is configured.
r.get('/lyrics', requireAuth, async (req, res) => {
  const { title = '', artist = '', variant = 'original', lang = 'en', durationMs = 0 } = req.query;
  const index = Math.max(0, parseInt(req.query.index, 10) || 0);

  if (process.env.MUSIXMATCH_API_KEY) {
    try {
      const key = process.env.MUSIXMATCH_API_KEY;
      const base = 'https://api.musixmatch.com/ws/1.1';
      const q = `q_track=${encodeURIComponent(title)}&q_artist=${encodeURIComponent(artist)}&apikey=${key}`;
      const sub = await (await fetch(`${base}/matcher.subtitle.get?${q}&subtitle_format=lrc`)).json();
      const body = sub.message?.body?.subtitle?.subtitle_body;
      let plain = '';
      if (!body) {
        const l = await (await fetch(`${base}/matcher.lyrics.get?${q}`)).json();
        plain = l.message?.body?.lyrics?.lyrics_body || '';
      }
      return res.json({ source: 'musixmatch', variant, lang, index: 0, count: 1, label: 'Musixmatch', synced: body ? parseLrc(body) : [], plain });
    } catch {
      return res.status(502).json({ error: 'Lyrics provider error' });
    }
  }

  let versions = [];
  try {
    versions = await lrclib(String(title), String(artist), durationMs);
  } catch {
    /* LRCLIB unreachable: fall through to the demo lyrics */
  }
  if (versions.length) {
    const i = Math.min(index, versions.length - 1);
    return res.json({ source: 'lrclib', variant, index: i, count: versions.length, ...versions[i] });
  }
  res.json({
    source: 'demo', variant, index: 0, count: 1, label: 'Moon Play demo',
    synced: parseLrc(DEMO_LRC), plain: DEMO_LRC.replace(/\[.*?\]/g, '').trim(),
  });
});

export default r;
