import { Router } from 'express';
import { nanoid } from 'nanoid';
import { db, save } from './db.js';
import { requireAuth } from './auth.js';

const r = Router();

const canView = (p, userId) =>
  p.ownerId === userId || p.collaborators.includes(userId) || p.isPublic;

// My playlists
r.get('/', requireAuth, (req, res) => {
  res.json(db.playlists.filter((p) => p.ownerId === req.user.id || p.collaborators.includes(req.user.id)));
});

r.post('/', requireAuth, (req, res) => {
  const { name, description = '', isPublic = false } = req.body || {};
  if (!name) return res.status(400).json({ error: 'name required' });
  const p = {
    id: nanoid(8),
    shareCode: nanoid(10),
    ownerId: req.user.id,
    name,
    description,
    isPublic,
    collaborators: [],
    tracks: [],
    createdAt: Date.now(),
  };
  db.playlists.push(p);
  save();
  res.status(201).json(p);
});

r.get('/:id', requireAuth, (req, res) => {
  const p = db.playlists.find((x) => x.id === req.params.id);
  if (!p || !canView(p, req.user.id)) return res.status(404).json({ error: 'Not found' });
  res.json(p);
});

r.post('/:id/tracks', requireAuth, (req, res) => {
  const p = db.playlists.find((x) => x.id === req.params.id);
  if (!p || !(p.ownerId === req.user.id || p.collaborators.includes(req.user.id)))
    return res.status(404).json({ error: 'Not found' });
  // The app sends the catalog track as-is ({ id, ... }); older clients send trackId.
  const b = req.body || {};
  const trackId = b.trackId || b.id;
  if (!trackId) return res.status(400).json({ error: 'trackId required' });
  // Keep stream/download URLs so a playlist can be played and downloaded later
  if (!p.tracks.some((t) => t.trackId === trackId))
    p.tracks.push({
      trackId, title: b.title, artist: b.artist, album: b.album || '', artwork: b.artwork || '',
      durationMs: b.durationMs || 0, streamUrl: b.streamUrl || '', downloadUrl: b.downloadUrl || '',
      addedBy: req.user.id, addedAt: Date.now(),
    });
  save();
  res.json(p);
});

r.delete('/:id', requireAuth, (req, res) => {
  const i = db.playlists.findIndex((x) => x.id === req.params.id && x.ownerId === req.user.id);
  if (i < 0) return res.status(404).json({ error: 'Not found' });
  db.playlists.splice(i, 1);
  save();
  res.json({ ok: true });
});

r.delete('/:id/tracks/:trackId', requireAuth, (req, res) => {
  const p = db.playlists.find((x) => x.id === req.params.id);
  if (!p || p.ownerId !== req.user.id) return res.status(404).json({ error: 'Not found' });
  p.tracks = p.tracks.filter((t) => t.trackId !== req.params.trackId);
  save();
  res.json(p);
});

// Share: resolve a share link/code, optionally copy it into my library
r.get('/shared/:code', requireAuth, (req, res) => {
  const p = db.playlists.find((x) => x.shareCode === req.params.code);
  if (!p) return res.status(404).json({ error: 'Invalid share link' });
  res.json(p);
});

r.post('/shared/:code/save', requireAuth, (req, res) => {
  const src = db.playlists.find((x) => x.shareCode === req.params.code);
  if (!src) return res.status(404).json({ error: 'Invalid share link' });
  const copy = {
    ...structuredClone(src),
    id: nanoid(8),
    shareCode: nanoid(10),
    ownerId: req.user.id,
    collaborators: [],
    isPublic: false,
    createdAt: Date.now(),
  };
  db.playlists.push(copy);
  save();
  res.status(201).json(copy);
});

// Share directly with a friend as collaborator
r.post('/:id/share/:friendId', requireAuth, (req, res) => {
  const p = db.playlists.find((x) => x.id === req.params.id && x.ownerId === req.user.id);
  if (!p) return res.status(404).json({ error: 'Not found' });
  if (!p.collaborators.includes(req.params.friendId)) p.collaborators.push(req.params.friendId);
  save();
  res.json(p);
});

export default r;
